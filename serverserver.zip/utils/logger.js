// utils/logger.js
const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const { ElasticsearchTransport } = require('winston-elasticsearch');

class EnterpriseLogger {
  constructor() {
    this.logger = this.createLogger();
    this.contextMap = new Map();
  }

  createLogger() {
    const format = winston.format.combine(
      winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss.SSS'
      }),
      winston.format.errors({ stack: true }),
      winston.format.splat(),
      winston.format.json(),
      winston.format.printf(info => {
        const { timestamp, level, message, ...meta } = info;
        
        // Add context information
        const context = this.contextMap.get(process.pid) || {};
        
        return JSON.stringify({
          timestamp,
          level,
          message,
          ...context,
          ...meta,
          environment: process.env.NODE_ENV,
          service: 'chat-server',
          version: process.env.npm_package_version
        });
      })
    );

    const transports = [];

    // Console transport
    if (process.env.NODE_ENV !== 'production') {
      transports.push(new winston.transports.Console({
        format: winston.format.combine(
          winston.format.colorize(),
          winston.format.simple()
        )
      }));
    }

    // File transport with rotation
    transports.push(new DailyRotateFile({
      filename: 'logs/application-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '14d',
      level: 'info'
    }));

    // Error file transport
    transports.push(new DailyRotateFile({
      filename: 'logs/error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '30d',
      level: 'error'
    }));

    // Elasticsearch transport for production
    if (process.env.ELASTICSEARCH_URL) {
      transports.push(new ElasticsearchTransport({
        level: 'info',
        clientOpts: {
          node: process.env.ELASTICSEARCH_URL,
          auth: {
            username: process.env.ELASTICSEARCH_USER,
            password: process.env.ELASTICSEARCH_PASSWORD
          }
        },
        index: 'chat-server-logs',
        dataStream: true
      }));
    }

    return winston.createLogger({
      level: process.env.LOG_LEVEL || 'info',
      format,
      transports,
      exceptionHandlers: [
        new winston.transports.File({ 
          filename: 'logs/exceptions.log' 
        })
      ],
      rejectionHandlers: [
        new winston.transports.File({ 
          filename: 'logs/rejections.log' 
        })
      ]
    });
  }

  // Context management
  setContext(context) {
    this.contextMap.set(process.pid, {
      ...this.contextMap.get(process.pid),
      ...context
    });
  }

  clearContext() {
    this.contextMap.delete(process.pid);
  }

  // Enhanced logging methods
  info(message, meta = {}) {
    this.logger.info(message, this.sanitizeMeta(meta));
  }

  error(message, meta = {}) {
    const errorMeta = this.processError(meta);
    this.logger.error(message, this.sanitizeMeta(errorMeta));
  }

  warn(message, meta = {}) {
    this.logger.warn(message, this.sanitizeMeta(meta));
  }

  debug(message, meta = {}) {
    this.logger.debug(message, this.sanitizeMeta(meta));
  }

  // Audit logging
  audit(action, meta = {}) {
    this.logger.info('AUDIT', {
      ...this.sanitizeMeta(meta),
      action,
      timestamp: new Date().toISOString(),
      userId: meta.userId,
      ip: meta.ip,
      userAgent: meta.userAgent
    });
  }

  // Performance logging
  performance(operation, duration, meta = {}) {
    this.logger.info('PERFORMANCE', {
      ...this.sanitizeMeta(meta),
      operation,
      duration,
      timestamp: new Date().toISOString()
    });
  }

  // Security logging
  security(event, meta = {}) {
    this.logger.warn('SECURITY', {
      ...this.sanitizeMeta(meta),
      event,
      timestamp: new Date().toISOString(),
      severity: meta.severity || 'medium'
    });
  }

  // Process error objects
  processError(meta) {
    if (meta.error instanceof Error) {
      return {
        ...meta,
        error: {
          message: meta.error.message,
          stack: meta.error.stack,
          code: meta.error.code,
          name: meta.error.name
        }
      };
    }
    return meta;
  }

  // Sanitize metadata
  sanitizeMeta(meta) {
    const sanitized = { ...meta };
    const sensitiveFields = [
      'password', 'token', 'secret', 'key', 'authorization',
      'credit_card', 'ssn', 'pin'
    ];

    Object.keys(sanitized).forEach(key => {
      if (sensitiveFields.some(field => 
        key.toLowerCase().includes(field)
      )) {
        sanitized[key] = '[REDACTED]';
      }
    });

    return sanitized;
  }

  // Create child logger
  child(defaultMeta) {
    const childLogger = Object.create(this);
    childLogger.logger = this.logger.child(defaultMeta);
    return childLogger;
  }

  // Measure operation duration
  startTimer() {
    const start = Date.now();
    return {
      done: (operation, meta = {}) => {
        const duration = Date.now() - start;
        this.performance(operation, duration, meta);
      }
    };
  }
}

module.exports = new EnterpriseLogger();